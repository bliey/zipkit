not encrypted
